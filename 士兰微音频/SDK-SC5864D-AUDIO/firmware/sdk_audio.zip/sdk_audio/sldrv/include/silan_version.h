/*
 * silan_version.h
 */

#ifndef __SILAN_VERSION_H__
#define __SILAN_VERSION_H__

void silan_sldrv_info(void);

#endif
