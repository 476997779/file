#ifndef __SILAN_CALIB_H__
#define __SILAN_CALIB_H__

void silan_calib(void);
char silan_get_softid(void);

#endif
