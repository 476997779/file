/*
 * types.h
 */

#ifndef __SILAN_TYPES_H__
#define __SILAN_TYPES_H__

#include "ap1508_datatype.h"

#endif
